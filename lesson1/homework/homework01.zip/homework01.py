num = int(input("Введите число >>>"))
float_num = float(input("Введите число с точкой >>>"))
name = str(input("Введите ваше имя:"))

print(f"Привет, {name}! Вы ввели целое число {num}. И число с остатком {float_num}")